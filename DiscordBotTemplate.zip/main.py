import os
import json

import discord
from discord.ext import commands


print(discord.__version__)

# Ustawienie stałych z configu
config = json.load(open('config.json', 'r'))
DISCORD_TOKEN = config['discord_token']
OWNER_IDS = [config['owner_id']]
INTENTS = discord.Intents.default()
INTENTS.message_content = True

# Stworzenie instancji bota. Tutaj są przekazywane informacje o bocie, 
# takie jak kto jest twórcą, jaki jest prefix komend tekstowych i inne.
bot = commands.Bot(
    command_prefix = f"{config['bot_number']}!",  # "numer_bota!" (np. "0!")
    help_command = None,
    intents = INTENTS,
    owner_ids = OWNER_IDS
)

# ========== LOADING COGS =========== #

# Ładowanie wszystkich cogów z folderu `cogs`.
# Wszystkie nowe cogi jakie dodacie, powinny same się załadować dzięki temu.

if __name__ == '__main__':
    print("\nloading cogs...")
    """
    Loads the cogs from the `./cogs` folder.
    Note:
        The cogs are named in this format `{cog_dir}.{cog_filename_without_extension}`.
    """

    for cog in os.listdir('cogs'):
        if cog.endswith('.py') is True:
            print(f"loading cogs.{cog[:-3]}...")
            bot.load_extension(f'cogs.{cog[:-3]}')
    print("plugins loaded :D")

# ========== ON READY =========== #

# `on_ready` jest wykonywane podczas startu bota, gdy już będą załadowane wszystkie jego cogi.
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}\n")

    # Ustawienie statusu bota na "Listening to /help"
    custom_activity = discord.Activity(type=2, name="/help")
    await bot.change_presence(activity=custom_activity)


# ========== ON MESSAGE =========== #


# `on_message` zostanie wykonane za każdym razem, jak ktoś coś napisze na serwerze.
@bot.event
async def on_message(message):

    # Jeżeli autorem wiadomości jest jakiś bot, lub on sam, to nic nie rób.
    if message.author == bot.user or message.author.bot is True:
        return

    # Przetwórz komendy tekstowe.
    # Note: slash komendy są automatycznie przetwarzane, więc nie są uruchamiane przez `on_message`.
    await bot.process_commands(message)


# ========== TEXT COMMANDS =========== #


# Dekorator `@bot.command()` tworzy komendę tekstową, która będzie uruchomiona poprzez napisanie na kanale
# prefixu naszego bota, przez nas ustawionego (np. "0!") + nazwy komendy. (np. "0!ping")
@bot.command(
    name="ping",
    brief="Test connection to bot",
    description="Test connection to bot",
    # hidden=True,
)
# Z dekoratorem `@commands.is_owner()` komenda będzie wykonana tylko, 
# jeżeli osobą będzie owner (u nas ustawiany w config.json)
@commands.is_owner()
async def ping(ctx):
    print("pinged")
    # Wiadomość wysyła się poprzez `ctx.send()`.
    # Więcej info o `ctx` dla komend tekstowych i jego metodach znajdziecie na:
    # https://docs.pycord.dev/en/stable/ext/commands/api.html#discord.ext.commands.Context
    await ctx.send("Pong!")


# Uruchom bota. To musi być na samym dole pliku!
bot.run(DISCORD_TOKEN)
