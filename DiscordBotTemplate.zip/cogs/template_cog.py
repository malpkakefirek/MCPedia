import discord


class Template(discord.Cog):
    # To jest inicjalizacja tego cog. Tym nie musicie się przejmować.
    def __init__(self, bot):
        self.bot = bot
        print(f"** SUCCESSFULLY LOADED {__name__} **")

    # Tutaj będą się znajdować wszystkie komendy z tego cog. Przykładowa komenda "/hello" znajduje się poniżej.

    # To jest dekorator. Tutaj możesz ustawić wszystkie informacje o komendzie, takie jak tytuł i opis
    @discord.slash_command(
        name = "hello",
        description = "Hi, Hello there!",
    )
    async def hello_world(
        self, 
        ctx, 
        name: discord.commands.Option(
            str,  # Typ zmiennej
            description = "What's your name?",  # Opis zmiennej
            default = "World",  # Domyślna wartość, jeżeli zmienna nie jest podana (automatycznie ustawia `required` na `False`)
        ),
    ):
        # Odpowiada się na komendę poprzez `ctx.respond()`
        # `ctx` posiada cały kontekst (stąd nazwa ctx) o interakcji użytkownika.
        # Więcej informacji o `ctx` dla slash komend i jego metodach znajdziecie na:
        # https://docs.pycord.dev/en/stable/api/application_commands.html#discord.ApplicationContext
        await ctx.respond(f"Hello {name}!")


# Tutaj jest dodawany ten cog do bota. Tym nie musicie się przejmować.
def setup(bot):
    bot.add_cog(Template(bot))
